#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

typedef struct procinfo {
  int pid;
  char pname[16];
}procs;

int
main(int argc, char *argv[])
{
  //struct procinfo pi;
  int i=0;
  procs* procinfoptr = (procs*) malloc(sizeof(struct procinfo)*64);
  //int total = getprocsinfo(&pi);
  int total = getprocsinfo(procinfoptr);
  if(total == -1)
  {
    printf(1,"Error occured!!\n");
    exit();
  }
  printf(1," Total current processes = %d\n", total);
  while(i<total){
    printf(1,"Process id = %d and process name = %s\n",procinfoptr[i].pid, procinfoptr[i].pname);
    i++;
  }
  free(procinfoptr);
  exit();
}
