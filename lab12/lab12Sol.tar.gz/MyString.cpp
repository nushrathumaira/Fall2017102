#include "MyString.hpp"

MyString::MyString ()
  : data(0), size(0) {}

MyString::MyString (const char* string)
  : data(new char[strlen(string)+1]), size(strlen(string)) {
    for (int i = 0; i < this->size; i++) {
      this->data[i] = string[i];
    }
    this->data[this->size] = '\0';
  }

MyString::MyString (const MyString& string)
  : data(new char[string.size+1]), size(string.size) {
    for (int i = 0; i < this->size; i++) {
      this->data[i] = string[i];
    }
    this->data[this->size] = '\0';
  }

MyString::~MyString () {
  if (this->size > 0) {
    delete [] this->data;
  }
}

int MyString::len () const {
  return this->size;
}

MyString& MyString::operator= (const MyString& string) {
  if (string.size > this->size) {
    delete [] this->data;
    this->data = new char[string.size + 1];
    this->size = string.size;
  }

  for (int i = 0; i < string.size; i++) {
    this->data[i] = string.data[i];
  }

  this->data[string.size] = '\0';
  return *this;
}

MyString& MyString::operator= (const char* string) {
  if (strlen(string) > this->size) {
    delete [] this->data;
    this->data = new char[strlen(string) + 1];
    this->size = strlen(string);
  }

  for (int i = 0; i < strlen(string); i++) {
    this->data[i] = string[i];
  }

  this->data[strlen(string)] = '\0';
  return *this;
}

MyString operator+ (const MyString& left, const MyString& right) {
  char* temp = new char[left.size + right.size + 1];

  int ndx = 0;

  for (int i = 0; i < left.size; i++) {
    temp[ndx] = left[i];
    ndx++;
  }

  for (int i = 0; i < right.size; i++) {
    temp[ndx] = right[i];
    ndx++;
  }

  temp[ndx] = '\0';

  MyString val(temp);

  delete [] temp;
  
  return val;
}

MyString operator+ (const MyString& left, const char* right) {
  return left + MyString(right);
}

MyString operator+ (const char* left, const MyString& right){
  return MyString(left) + right;
}

char MyString::operator[] (int ndx) const {
  if (ndx >= 0 && ndx < this->size) {
    return this->data[ndx];
  } else {
    cout << "Invalid Index - Terminating" << endl;
    exit(-1);
  }
}

ostream& operator<<(ostream& out, const MyString& string) {
  for (int i = 0; i < string.size; i++) {
    out << string.data[i];
  }
  return out;
}
